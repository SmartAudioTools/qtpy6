"""The apply module."""

from .apply import apply

__all__ = ['apply']  # Re-export attribute
